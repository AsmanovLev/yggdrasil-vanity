/*
 * entry.cl — GPU-side keygen + scoring + candidate filtering
 *
 * Each work-item generates one ed25519 keypair, computes the Yggdrasil
 * address score, and — if the score beats the threshold — appends a
 * candidate record to the output buffer using an atomic counter.
 *
 * Output layout (candidates buffer):
 *   [0..3]   uint  — number of candidates written (atomic counter)
 *   [4..N]   candidate records, each CANDIDATE_STRIDE bytes:
 *               [0..31]  seed    (32 bytes)
 *               [32..63] pubkey  (32 bytes)
 *               [64..71] score   (int64, little-endian, fixed-point *1000000)
 *
 * Inputs:
 *   seeds    — flat array: thread * 32 .. thread * 32 + 31
 *   threshold_buf — int64 LE: current best_score - capture_range (fixed *1e6)
 *   formula_id — uint: selects scoring formula (see below)
 *   fw / lw  — float: formula weights passed as kernel args
 */

#define MAX_CANDIDATES  65536
#define CANDIDATE_STRIDE 72   /* 32 seed + 32 pubkey + 8 score */
#define CANDIDATES_HEADER 4   /* uint counter at start */

/* ------------------------------------------------------------------ */
/* leading-zero count of pubkey (Yggdrasil "height")                  */
/* ------------------------------------------------------------------ */
static uchar leading_zeros_pubkey(__private uchar *pk) {
    uchar zeros = 0;
    for (int i = 0; i < 32; i++) {
        uchar b = pk[i];
        if (b == 0) {
            zeros += 8;
        } else {
            /* clz on uchar via shift */
            uchar z = 0;
            if ((b & 0xF0) == 0) { z += 4; b <<= 4; }
            if ((b & 0xC0) == 0) { z += 2; b <<= 2; }
            if ((b & 0x80) == 0) { z += 1; }
            zeros += z;
            break;
        }
    }
    return zeros;
}

/* ------------------------------------------------------------------ */
/* Yggdrasil subnet string length estimation                           */
/*                                                                     */
/* Full address_for_pubkey produces an IPv6 in the 02xx::/16 range.   */
/* The string length of its to_string() in Rust depends on how many   */
/* groups compress to "::". We approximate the length using the same   */
/* byte construction as the Rust code, then count non-zero 16-bit     */
/* groups to estimate the compressed IPv6 string length.              */
/*                                                                     */
/* Exact match isn't needed — scoring only needs a consistent metric. */
/* ------------------------------------------------------------------ */
static uchar subnet_length_approx(uchar height, __private uchar *pk) {
    uchar buf[16];
    buf[0] = 0x02 | 0x01;   /* subnet: first byte has bit 0 set */
    buf[1] = height;
    /* lower 8 bytes zeroed for /64 subnet */
    for (int i = 8; i < 16; i++) buf[i] = 0;

    /* fill buf[2..7] with the same XOR shift as Rust address_for_pubkey */
    int shift = (height + 1) % 8;
    int byte_off = height / 8;
    for (int j = 0; j < 6; j++) {
        int src = byte_off + j;
        if (src + 1 < 32) {
            buf[2 + j] = (uchar)(
                (pk[src]   << shift) ^
                (pk[src+1] >> (8 - shift)) ^
                0xFF
            );
        } else {
            buf[2 + j] = 0xFF;
        }
    }
    buf[8] = 0; /* /64 subnet lower half zeroed */

    /*
     * Count the compressed IPv6 string length.
     * Groups: buf[0..1], buf[2..3], buf[4..5], buf[6..7], then 0,0,0,0
     * The last four groups are always zero so they compress to "::".
     * We count the non-zero upper groups and estimate length.
     *
     * Format: "XXXX:XXXX:XXXX:XXXX::" = 4 groups * 5 chars - 1 + 2 = 21..39
     */
    int len = 0;
    /* last 4 groups are always 0 — compressed as "::" = 2 chars */
    len += 2;
    /* first 4 groups, each printed as 1-4 hex digits + ":" separator */
    for (int g = 0; g < 4; g++) {
        uint16_t grp = ((uint)buf[g*2] << 8) | (uint)buf[g*2+1];
        if (grp == 0) {
            len += 1; /* "0" */
        } else if (grp < 0x10) {
            len += 1;
        } else if (grp < 0x100) {
            len += 2;
        } else if (grp < 0x1000) {
            len += 3;
        } else {
            len += 4;
        }
        len += 1; /* ":" separator */
    }
    return (uchar)len;
}

/* ------------------------------------------------------------------ */
/* Score formula dispatch                                               */
/* formula_id:                                                         */
/*   0  →  h               (default, height only)                     */
/*   1  →  fw*h - lw*l     (weighted linear)                          */
/*   2  →  h^fw / (l^lw)   (power ratio)                              */
/*   3  →  fw*h*h - lw*l   (quadratic height)                         */
/* Score is returned as int64 fixed-point * 1000000                   */
/* ------------------------------------------------------------------ */
static long compute_score(uchar h, uchar l, uint formula_id, float fw, float lw) {
    float hf = (float)h;
    float lf = (float)l;
    float score;
    switch (formula_id) {
        case 1:  score = fw * hf - lw * lf; break;
        case 2:  score = pow(hf, fw) / (pow(lf, lw) + 1e-9f); break;
        case 3:  score = fw * hf * hf - lw * lf; break;
        default: score = hf; break;   /* formula_id == 0 */
    }
    return (long)(score * 1000000.0f);
}

/* ------------------------------------------------------------------ */
/* Main kernel                                                          */
/* ------------------------------------------------------------------ */
__kernel void generate_pubkey(
    __global uchar  *candidates,   /* output: header(4B) + records     */
    __global uchar  *seeds,        /* input:  seeds, 32B per thread     */
    __global uchar  *threshold_buf,/* input:  int64 LE threshold        */
    uint             formula_id,
    float            fw,
    float            lw
) {
    size_t thread = get_global_id(0);

    /* Read threshold (int64 little-endian) */
    long threshold = 0;
    __global uchar *tb = threshold_buf;
    for (int i = 0; i < 8; i++) {
        threshold |= ((long)tb[i]) << (i * 8);
    }

    /* Load seed */
    uchar key[32];
    for (int i = 0; i < 32; i++) {
        key[i] = seeds[thread * 32 + i];
    }

    /* Ed25519 keygen (existing pipeline) */
    uchar hash[64];
    sha512_hash(&key, &hash);
    hash[0] &= 248;
    hash[31] &= 63;
    hash[31] |= 64;

    bignum256modm a;
    ge25519 ALIGN(16) A;
    expand256_modm(a, hash, 32);
    ge25519_scalarmult_base_niels(&A, a);

    uchar pubkey[32];
    ge25519_pack(pubkey, &A);

    /* Score */
    uchar h = leading_zeros_pubkey(pubkey);
    uchar l = subnet_length_approx(h, pubkey);
    long  score = compute_score(h, l, formula_id, fw, lw);

    if (score < threshold) return;

    /* Atomically claim a slot in the candidates buffer */
    __global uint *counter = (__global uint *)candidates;
    uint slot = atomic_inc(counter);
    if (slot >= MAX_CANDIDATES) return;  /* buffer full — drop */

    /* Write candidate: seed[32] + pubkey[32] + score[8] */
    __global uchar *out = candidates + CANDIDATES_HEADER + slot * CANDIDATE_STRIDE;
    for (int i = 0; i < 32; i++) out[i]      = key[i];
    for (int i = 0; i < 32; i++) out[32 + i] = pubkey[i];
    /* score as int64 little-endian */
    long s = score;
    for (int i = 0; i < 8; i++) {
        out[64 + i] = (uchar)(s & 0xFF);
        s >>= 8;
    }
}
