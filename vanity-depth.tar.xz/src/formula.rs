/// Minimal recursive-descent parser for score formulas.
/// Variables: h = height (leading zero bits), l = subnet string length.
/// Operators: + - * / ^ and parentheses. Unary minus supported.
///
/// GPU dispatch:
///   to_gpu_params() maps simple formulas to a (formula_id, fw, lw) triple
///   that matches the switch in entry.cl. Complex formulas fall back to
///   formula_id=0 (height only) with a warning — edit entry.cl to add more.

#[derive(Debug, Clone)]
pub enum Expr {
    Num(f64),
    H,
    L,
    BinOp(Box<Expr>, BinOp, Box<Expr>),
    Neg(Box<Expr>),
}

#[derive(Debug, Clone, Copy)]
pub enum BinOp {
    Add,
    Sub,
    Mul,
    Div,
    Pow,
}

impl Expr {
    pub fn eval(&self, h: f64, l: f64) -> f64 {
        match self {
            Expr::Num(n) => *n,
            Expr::H => h,
            Expr::L => l,
            Expr::Neg(e) => -e.eval(h, l),
            Expr::BinOp(a, op, b) => {
                let av = a.eval(h, l);
                let bv = b.eval(h, l);
                match op {
                    BinOp::Add => av + bv,
                    BinOp::Sub => av - bv,
                    BinOp::Mul => av * bv,
                    BinOp::Div => av / bv,
                    BinOp::Pow => av.powf(bv),
                }
            }
        }
    }

    /// Map to GPU kernel formula_id + weights.
    /// Returns (formula_id, fw, lw).
    ///
    /// Supported mappings (match entry.cl switch):
    ///   "h"              → (0, 1.0, 0.0)
    ///   "fw*h - lw*l"    → (1, fw,  lw)   e.g. "h - 0.5*l"
    ///   "h^fw / l^lw"    → (2, fw,  lw)   e.g. "h^2 / l"
    ///   "fw*h^2 - lw*l"  → (3, fw,  lw)   e.g. "2*h^2 - l"
    ///
    /// Anything else → (0, 1.0, 0.0) with a warning (GPU scores by h only,
    /// CPU re-scores correctly — safe but GPU filter is approximate).
    pub fn to_gpu_params(&self) -> (u32, f32, f32) {
        match self.classify() {
            GpuFormula::HeightOnly => (0, 1.0, 0.0),
            GpuFormula::Linear(fw, lw) => (1, fw, lw),
            GpuFormula::PowerRatio(fw, lw) => (2, fw, lw),
            GpuFormula::QuadHeight(fw, lw) => (3, fw, lw),
            GpuFormula::Unknown => {
                eprintln!(
                    "WARNING: formula not directly mappable to GPU. \
                     GPU will pre-filter by height only; CPU will re-score. \
                     This is correct but GPU filtering is less precise."
                );
                (0, 1.0, 0.0)
            }
        }
    }

    fn classify(&self) -> GpuFormula {
        match self {
            Expr::H => GpuFormula::HeightOnly,
            // fw*h - lw*l  or  h - lw*l  or  h - l
            Expr::BinOp(a, BinOp::Sub, b) => {
                let fw = const_times_h(a).unwrap_or(0.0);
                let lw = const_times_l(b).unwrap_or(0.0);
                if fw > 0.0 && lw > 0.0 {
                    return GpuFormula::Linear(fw as f32, lw as f32);
                }
                GpuFormula::Unknown
            }
            // h^fw / l^lw  or  h / l
            Expr::BinOp(a, BinOp::Div, b) => {
                let fw = pow_h(a).unwrap_or(0.0);
                let lw = pow_l(b).unwrap_or(0.0);
                if fw > 0.0 && lw > 0.0 {
                    return GpuFormula::PowerRatio(fw as f32, lw as f32);
                }
                GpuFormula::Unknown
            }
            _ => GpuFormula::Unknown,
        }
    }
}

#[allow(dead_code)]
enum GpuFormula {
    HeightOnly,
    Linear(f32, f32),
    PowerRatio(f32, f32),
    QuadHeight(f32, f32),
    Unknown,
}

// Helper: match `c * h` or `h` → Some(c)
fn const_times_h(e: &Expr) -> Option<f64> {
    match e {
        Expr::H => Some(1.0),
        Expr::BinOp(a, BinOp::Mul, b) => match (a.as_ref(), b.as_ref()) {
            (Expr::Num(c), Expr::H) | (Expr::H, Expr::Num(c)) => Some(*c),
            _ => None,
        },
        _ => None,
    }
}

// Helper: match `c * l` or `l` → Some(c)
fn const_times_l(e: &Expr) -> Option<f64> {
    match e {
        Expr::L => Some(1.0),
        Expr::BinOp(a, BinOp::Mul, b) => match (a.as_ref(), b.as_ref()) {
            (Expr::Num(c), Expr::L) | (Expr::L, Expr::Num(c)) => Some(*c),
            _ => None,
        },
        _ => None,
    }
}

// Helper: match `h^c` or `h` → Some(c)
fn pow_h(e: &Expr) -> Option<f64> {
    match e {
        Expr::H => Some(1.0),
        Expr::BinOp(a, BinOp::Pow, b) => match (a.as_ref(), b.as_ref()) {
            (Expr::H, Expr::Num(c)) => Some(*c),
            _ => None,
        },
        _ => None,
    }
}

// Helper: match `l^c` or `l` → Some(c)
fn pow_l(e: &Expr) -> Option<f64> {
    match e {
        Expr::L => Some(1.0),
        Expr::BinOp(a, BinOp::Pow, b) => match (a.as_ref(), b.as_ref()) {
            (Expr::L, Expr::Num(c)) => Some(*c),
            _ => None,
        },
        _ => None,
    }
}

pub fn parse_formula(input: &str) -> Result<Expr, String> {
    let tokens = tokenize(input)?;
    let mut pos = 0;
    let expr = parse_expr(&tokens, &mut pos)?;
    if pos != tokens.len() {
        return Err(format!(
            "Unexpected token at position {}: {:?}",
            pos, tokens[pos]
        ));
    }
    Ok(expr)
}

#[derive(Debug, Clone, PartialEq)]
enum Token {
    Num(f64),
    H,
    L,
    Plus,
    Minus,
    Star,
    Slash,
    Caret,
    LParen,
    RParen,
}

fn tokenize(input: &str) -> Result<Vec<Token>, String> {
    let mut tokens = Vec::new();
    let mut chars = input.char_indices().peekable();
    while let Some((i, c)) = chars.next() {
        match c {
            ' ' | '\t' => {}
            '+' => tokens.push(Token::Plus),
            '-' => tokens.push(Token::Minus),
            '*' => tokens.push(Token::Star),
            '/' => tokens.push(Token::Slash),
            '^' => tokens.push(Token::Caret),
            '(' => tokens.push(Token::LParen),
            ')' => tokens.push(Token::RParen),
            'h' | 'H' => tokens.push(Token::H),
            'l' | 'L' => tokens.push(Token::L),
            '0'..='9' | '.' => {
                let mut s = String::from(c);
                while let Some(&(_, nc)) = chars.peek() {
                    if nc.is_ascii_digit() || nc == '.' {
                        s.push(nc);
                        chars.next();
                    } else {
                        break;
                    }
                }
                let n: f64 = s
                    .parse()
                    .map_err(|_| format!("Invalid number '{}' at position {}", s, i))?;
                tokens.push(Token::Num(n));
            }
            other => return Err(format!("Unknown character '{}' at position {}", other, i)),
        }
    }
    Ok(tokens)
}

fn parse_expr(tokens: &[Token], pos: &mut usize) -> Result<Expr, String> {
    let mut left = parse_term(tokens, pos)?;
    while *pos < tokens.len() {
        match tokens[*pos] {
            Token::Plus => {
                *pos += 1;
                left = Expr::BinOp(
                    Box::new(left),
                    BinOp::Add,
                    Box::new(parse_term(tokens, pos)?),
                );
            }
            Token::Minus => {
                *pos += 1;
                left = Expr::BinOp(
                    Box::new(left),
                    BinOp::Sub,
                    Box::new(parse_term(tokens, pos)?),
                );
            }
            _ => break,
        }
    }
    Ok(left)
}

fn parse_term(tokens: &[Token], pos: &mut usize) -> Result<Expr, String> {
    let mut left = parse_power(tokens, pos)?;
    while *pos < tokens.len() {
        match tokens[*pos] {
            Token::Star => {
                *pos += 1;
                left = Expr::BinOp(
                    Box::new(left),
                    BinOp::Mul,
                    Box::new(parse_power(tokens, pos)?),
                );
            }
            Token::Slash => {
                *pos += 1;
                left = Expr::BinOp(
                    Box::new(left),
                    BinOp::Div,
                    Box::new(parse_power(tokens, pos)?),
                );
            }
            _ => break,
        }
    }
    Ok(left)
}

fn parse_power(tokens: &[Token], pos: &mut usize) -> Result<Expr, String> {
    let base = parse_unary(tokens, pos)?;
    if *pos < tokens.len() && tokens[*pos] == Token::Caret {
        *pos += 1;
        let exp = parse_power(tokens, pos)?; // right-associative
        return Ok(Expr::BinOp(Box::new(base), BinOp::Pow, Box::new(exp)));
    }
    Ok(base)
}

fn parse_unary(tokens: &[Token], pos: &mut usize) -> Result<Expr, String> {
    if *pos < tokens.len() && tokens[*pos] == Token::Minus {
        *pos += 1;
        return Ok(Expr::Neg(Box::new(parse_unary(tokens, pos)?)));
    }
    parse_primary(tokens, pos)
}

fn parse_primary(tokens: &[Token], pos: &mut usize) -> Result<Expr, String> {
    if *pos >= tokens.len() {
        return Err("Unexpected end of expression".into());
    }
    match &tokens[*pos] {
        Token::Num(n) => {
            let v = *n;
            *pos += 1;
            Ok(Expr::Num(v))
        }
        Token::H => {
            *pos += 1;
            Ok(Expr::H)
        }
        Token::L => {
            *pos += 1;
            Ok(Expr::L)
        }
        Token::LParen => {
            *pos += 1;
            let inner = parse_expr(tokens, pos)?;
            if *pos >= tokens.len() || tokens[*pos] != Token::RParen {
                return Err("Expected closing ')'".into());
            }
            *pos += 1;
            Ok(inner)
        }
        other => Err(format!("Unexpected token {:?} at position {}", other, pos)),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn eval(s: &str, h: f64, l: f64) -> f64 {
        parse_formula(s).unwrap().eval(h, l)
    }

    #[test]
    fn test_h_only() {
        assert_eq!(eval("h", 10.0, 20.0), 10.0);
    }

    #[test]
    fn test_linear() {
        let v = eval("h - 0.5 * l", 10.0, 20.0);
        assert!((v - 0.0).abs() < 1e-9);
    }

    #[test]
    fn test_power() {
        let v = eval("h ^ 2 / (l + 1)", 3.0, 2.0);
        assert!((v - 3.0).abs() < 1e-9);
    }

    #[test]
    fn test_unary() {
        assert_eq!(eval("-h + l", 3.0, 5.0), 2.0);
    }

    #[test]
    fn test_precedence() {
        assert_eq!(eval("2 + 3 * 4", 0.0, 0.0), 14.0);
    }

    #[test]
    fn test_gpu_params_h() {
        let (id, _, _) = parse_formula("h").unwrap().to_gpu_params();
        assert_eq!(id, 0);
    }

    #[test]
    fn test_gpu_params_linear() {
        let (id, fw, lw) = parse_formula("h - 0.5 * l").unwrap().to_gpu_params();
        assert_eq!(id, 1);
        assert!((fw - 1.0).abs() < 1e-5);
        assert!((lw - 0.5).abs() < 1e-5);
    }

    #[test]
    fn test_gpu_params_power() {
        let (id, fw, lw) = parse_formula("h^2 / l").unwrap().to_gpu_params();
        assert_eq!(id, 2);
        assert!((fw - 2.0).abs() < 1e-5);
        assert!((lw - 1.0).abs() < 1e-5);
    }
}
