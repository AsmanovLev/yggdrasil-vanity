use std::{fs, io::Write, sync::Mutex};

use clap::Parser;

mod cpu;
mod formula;
mod gpu;
mod handler;

use cpu::run_cpu;
use formula::parse_formula;
use gpu::run_opencl;

#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
pub struct Args {
    /// Disable OpenCL (use CPU instead)
    #[arg(short = 'c', long, default_value_t = false)]
    disable_opencl: bool,

    /// OpenCL thread count.
    /// Default 4M is tuned for RTX 3060 Laptop (6 GB VRAM).
    /// Seeds: 128 MB, candidates buf: ~4.5 MB. Raise if GPU utilisation <90%.
    #[arg(short, long, default_value_t = 4 * 1024 * 1024)]
    threads: usize,

    /// OpenCL local work size (leave unset to let driver choose)
    #[arg(short, long)]
    local_work_size: Option<usize>,

    /// OpenCL platform index
    #[arg(short, long, default_value_t = 0)]
    platform_idx: usize,

    /// OpenCL device index
    #[arg(short, long, default_value_t = 0)]
    device_idx: usize,

    /// Log hashrate every N seconds
    #[arg(short = 'i', long, default_value_t = 10)]
    log_interval: u64,

    /// CSV file to write results to
    #[arg(short = 'f', long)]
    csv_file: Option<String>,

    /// Scoring formula. Variables: h = height (leading zero bits), l = subnet string length.
    /// Operators: + - * / ^ and parentheses. Higher score = better result.
    ///
    /// Range of values:
    ///   h (height): 0 to 256. Higher is better (more leading zero bits).
    ///   l (length): 5 to 21. Lower is better (shorter IPv6 string representation).
    ///
    /// Default "h" = optimise height only (original behaviour).
    ///
    /// Simple formulas are evaluated directly on the GPU (fast path).
    /// Supported GPU-native forms:
    ///   "h"              height only
    ///   "h - 0.5 * l"    weighted linear  (fw*h - lw*l)
    ///   "h^2 / l"        power ratio      (h^fw / l^lw)
    ///
    /// Anything else: GPU pre-filters by height; CPU re-scores (correct, slightly less efficient).
    #[arg(long, default_value = "h")]
    formula: String,

    /// Save results within this many score points below the current best.
    /// 0.0 = only new records. Higher = also save near-records.
    #[arg(long, default_value_t = 0.0)]
    capture_range: f64,
}

fn main() {
    let child = std::thread::Builder::new()
        .stack_size(16 * 1024 * 1024)
        .spawn(main_)
        .unwrap();
    child.join().unwrap();
}

fn main_() {
    let args = Args::parse();

    let formula = parse_formula(&args.formula).unwrap_or_else(|e| {
        eprintln!("Invalid formula '{}': {}", args.formula, e);
        std::process::exit(1);
    });

    eprintln!(
        "Formula: \"{}\"  |  capture_range: {}  |  threads: {}",
        args.formula, args.capture_range, args.threads,
    );

    let csv_file = args.csv_file.clone().map(|path| {
        let mut f = fs::OpenOptions::new()
            .append(true)
            .create(true)
            .open(path)
            .unwrap();
        if f.metadata().unwrap().len() == 0 {
            f.write_all(b"timestamp,subnet,address,height,length,score,privatekey\n")
                .unwrap();
        }
        Mutex::new(f)
    });

    if !args.disable_opencl {
        run_opencl(&args, &formula, args.capture_range, &csv_file)
    } else {
        run_cpu(&args, &formula, args.capture_range, &csv_file)
    }
}
